declare module "@salesforce/resourceUrl/callIcon" {
    var callIcon: string;
    export default callIcon;
}
declare module "@salesforce/resourceUrl/Hangup" {
    var Hangup: string;
    export default Hangup;
}
declare module "@salesforce/resourceUrl/Call" {
    var Call: string;
    export default Call;
}
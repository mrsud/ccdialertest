declare module "@salesforce/contentAssetUrl/Cloud_Connect_Logo" {
    var Cloud_Connect_Logo: string;
    export default Cloud_Connect_Logo;
}
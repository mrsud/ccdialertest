declare module "@salesforce/label/c.Not_Registered" {
    var Not_Registered: string;
    export default Not_Registered;
}
declare module "@salesforce/resourceUrl/SIP" {
    var SIP: string;
    export default SIP;
}
declare module "@salesforce/resourceUrl/NewCCDialerLogo" {
    var NewCCDialerLogo: string;
    export default NewCCDialerLogo;
}
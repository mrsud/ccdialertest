declare module "@salesforce/resourceUrl/dialer_logo" {
    var dialer_logo: string;
    export default dialer_logo;
}
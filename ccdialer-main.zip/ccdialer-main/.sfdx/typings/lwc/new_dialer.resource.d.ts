declare module "@salesforce/resourceUrl/new_dialer" {
    var new_dialer: string;
    export default new_dialer;
}
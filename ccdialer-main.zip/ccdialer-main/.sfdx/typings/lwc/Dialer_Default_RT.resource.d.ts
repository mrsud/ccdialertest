declare module "@salesforce/resourceUrl/Dialer_Default_RT" {
    var Dialer_Default_RT: string;
    export default Dialer_Default_RT;
}
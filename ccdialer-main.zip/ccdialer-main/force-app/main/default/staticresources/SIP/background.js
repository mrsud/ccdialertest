
$(document).ready(() => {
    //checkCreds();
    $("._sipExtension").keypress((e) => { (e.which == 13) ? validateLogin() : ''; });
    $("._sipPassword").keypress((e) => { (e.which == 13) ? validateLogin() : ''; });
    $("._sipServer").keypress((e) => { (e.which == 13) ? validateLogin() : ''; });
    $("._wssServer").keypress((e) => { (e.which == 13) ? validateLogin() : ''; });
});

console.options = {
    "closeButton": true,
    "debug": false,
    "newestOnTop": true,
    "progressBar": true,
    "positionClass": "toast-bottom-center",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "3000",
    "extendedTimeOut": "1000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
}
let _webCamAvailable = false;

let checkCreds = () => {
    let _loginState = store.get('_loginState');

    if (Boolean(_loginState) == true) {
        $('._loginBox').hide();
        $('._layoutBox').show();
        enableLogin();
    } else {
        $('._layoutBox').hide();
        $('._loginBox').show();
        fillPreConfiguration();
    }
}

let enableLogin = () => {
    let _loginState = store.get('_loginState');
    let _defaultCreds = store.get('_defaultCreds');
    if (Boolean(_loginState) == true) {
        phone.createUA();
        checkVideoAvailability();
        $('._regExtension').html(_defaultCreds._sipExtension);
    }
}

let enableLogout = () => {
    try {
        phone.logout();
    } catch (e) {
        console.log(e);
    }

    $('._layoutBox').hide();
    fillPreConfiguration();
    $('._loginBox').show();
}

$('body').on('click', '.add_account', function (e) {
    validateLogin($(this).attr('data-type'));
});

let validateLogin = () => {
    let _sipExtension, _sipPassword, _sipServer, _wssServer;
    _sipExtension = getVal("._sipExtension");
    _sipPassword = getVal("._sipPassword");
    _sipServer = getVal("._sipServer");
    _wssServer = getVal("._wssServer");

    if (validate(_sipExtension)) {
        console.error("SIP Extension is required.");
        return false;
    }

    // if (validate( _sipExtension , 'alphanumeric')) {
    //     console.error("SIP Extension must be alphanumeric only.");
    //     return false;
    // }

    if (validate(_sipPassword)) {
        console.error("SIP Password is required.");
        return false;
    }

    if (validate(_sipServer)) {
        console.error("SIP Server is required.");
        return false;
    }

    if (validate(_wssServer)) {
        console.error("WSS Server is required.");
        return false;
    }

    let _defaultCreds = store.get('_defaultCreds');
    if (isEmpty(_defaultCreds)) {
        _defaultCreds = {};
    }
    _defaultCreds._sipExtension = _sipExtension;
    _defaultCreds._sipPassword = _sipPassword;
    _defaultCreds._sipServer = _sipServer;
    _defaultCreds._wssServer = _wssServer;

    store.set('_defaultCreds', _defaultCreds);

    store.set('_accountCreds', {
        "_sipExtension": _sipExtension,
        "_sipPassword": _sipPassword,
        "_sipServer": _sipServer,
        "_wssServer": _wssServer
    });

    store.set('_loginState', true);
    enableLogin();
    $('._loginBox').hide();
    $('._layoutBox').show();
}

let fillPreConfiguration = () => {
    let _defaultCreds = store.get('_defaultCreds');
    if (!isEmpty(_defaultCreds)) {
        if (!isEmpty(_defaultCreds._sipExtension)) {
            setVal("._sipExtension", _defaultCreds._sipExtension);
        }
        if (!isEmpty(_defaultCreds._sipPassword)) {
            setVal("._sipPassword", _defaultCreds._sipPassword);
        }
        if (!isEmpty(_defaultCreds._sipServer)) {
            setVal("._sipServer", _defaultCreds._sipServer);
        }
        if (!isEmpty(_defaultCreds._wssServer)) {
            setVal("._wssServer", _defaultCreds._wssServer);
        }
    }
}

let validJSON = (_object) => {
    try {
        JSON.parse(_object);
    } catch (e) {
        return false;
    }
    return true;
}

// Dialpad related scripts
$('body').on('click', '._signOut', (r) => {
    store.remove('_accountCreds');
    store.remove('_loginState');
    updateRegisterState('connecting');
    enableLogout();
});

let updateRegisterState = (status) => {
    switch (status) {
        case 'registered':
            $('._regStateIcon').removeClass('text-danger').addClass('text-success');
            $('._regStateStatus').html('Registered');
            break;
        case 'connecting':
            $('._regStateIcon').removeClass('text-success').addClass('text-danger');
            $('._regStateStatus').html('Connecting');
            break;
        case 'disconnected':
            $('._regStateIcon').removeClass('text-success').addClass('text-danger');
            $('._regStateStatus').html('Connection Failed');
            break;
        case 'unregistered':
            $('._regStateIcon').removeClass('text-success').addClass('text-danger');
            $('._regStateStatus').html('Not Registered');
            break;
        default: break;
    }
}


$('body').on('click', '.dialpad_btn', function (e) {
    setVal("#phone_number", getVal("#phone_number") + $(this).attr("data-dialpad"));
});

$('body').on('click', '.clear_number', (r) => {
    let yourString = getVal('#phone_number');
    let result = yourString.substring(0, yourString.length - 1);
    setVal("#phone_number", result);
    $('#phone_number').focus();
});

let checkVideoAvailability = () => {
    detechVideoDevice((_webCam) => {
        _webCamAvailable = _webCam;
        console.log(' _webCamAvailable in checkVideoAvailability ' + _webCam)
        $('#dial_video').prop('disabled', !_webCam);
    });
}

let detechVideoDevice = (callback) => {
    let md = navigator.mediaDevices;
    if (!md || !md.enumerateDevices) return callback(false);
    md.enumerateDevices().then(devices => {
        callback(devices.some(device => 'videoinput' === device.kind));
    })
}

$('body').on('click', '#dial_audio', (r) => {
    console.log('I am clicked ');
    phone.dial(getVal("#phone_number"), false);
    setVal("#phone_number", "");
});


$('body').on('click', '#dial_video', (r) => {
    phone.dial(getVal("#phone_number"), true);
    setVal("#phone_number", "");
});


let handleCallSession = (data) => {
    if (data.callDirection == 'incoming') {
        $('._activeCalls').append(generateIncomingCallUI(data));
    } else {
        $('._activeCalls').append(generateOutgoingCallUI(data));
    }
}

let generateIncomingCallUI = (data) => {

    console.log(" _webCamAvailable : " + _webCamAvailable);
    let _colXs = (_webCamAvailable) ? 'col-xs-4' : 'col-xs-6';
    return '<div class="box box-solid shadow-none _sessionDiv">\
        <div class="box-header" style="cursor: pointer;">\
          <i class="fa fa-arrow-circle-down fa-2x"></i> Incoming Call\
        </div>\
        <div class="box-body">\
          <div class="row">\
            <div class="col-xs-12 text-center padding-10" style="color: #bfbfbf;">\
                <i class="fa fa-user fa-3x"></i>\
            </div>\
            <div class="col-xs-12 text-center padding-10">\
                '+ data.fromName + ' (' + data.from + ')\
            </div>\
            <div class="col-xs-12">&nbsp;</div>\
            <div class="col-xs-12">\
                <div class="'+ _colXs + ' text-right">\
                    <button type="button" class="btn col-xs-12 btn-success answer" data-state="audio"><i class="fa fa-phone"></i></button>\
                </div>\
                '+ ((_webCamAvailable) ? ('<div class="' + _colXs + ' text-right"><button type="button" class="btn col-xs-12 btn-success answer" data-state="video"><i class="fa fa-video-camera"></i></button></div>') : '') + '\
                <div class="'+ _colXs + ' text-left">\
                    <button type="button" class="btn col-xs-12 btn-danger hangup"><i class="fa fa-phone" style="transform:rotate(135deg);"></i></button>\
                </div>\
            </div>\
          </div>\
        </div>\
      </div>';
}
/*
          <div class="col-md-12 col-sm-12 col-xs-12">\
                <video autoplay id="remoteVideo"></video>\
                <video autoplay id="localVideo" class="col-md-4 col-sm-4 col-lg-4" style="position: absolute; right: 0; bottom: 0;" ></video>\
            </div>\
*/

let generateOutgoingCallUI = (data) => {
    return '<div class="box box-solid shadow-none _sessionDiv">\
        <div class="box-header">\
          <i class="fa fa-arrow-circle-'+ ((data.callDirection == "outgoing") ? "up" : "down") + ' fa-2x"></i> <span class="_caller">' + data.fromName + ' (' + data.from + ')</span>\
        </div>\
        <div class="box-body">\
            <div class="row">\
              <div class="col-xs-12 text-center padding-10" style="color: #bfbfbf;">\
                  <i class="fa fa-user fa-3x"></i>\
              </div>\
              <div class="col-xs-12 text-center padding-10 _timer">\
                  00:00:00\
              </div>\
              <div class="dtmf_pad padding-10" style="display: none;">\
              <div class="col-sm-12">\
                <div class="input-group">\
                    <input type="text" class="form-control external_txt dtmf_number" placeholder="Enter DTMF Number" autocomplete="off" autofocus="">\
                    <span class="input-group-addon btn clear_number"><i class="fa fa-close"></i></span>\
                </div>\
                </div>\
                '+ getDialPad("dtmf") + '\
                </div>\
                <div class="blind_tx_pad padding-10" style="display: none;">\
                <div class="col-sm-12">\
                  <div class="input-group">\
                      <span class="input-group-addon btn blind_tx"><i class="fa fa-mail-forward"></i></span>\
                      <input type="text" class="form-control external_txt blind_tx_number" placeholder="Enter Number" autocomplete="off" autofocus="">\
                      <span class="input-group-addon btn clear_number"><i class="fa fa-close"></i></span>\
                  </div>\
                </div>\
                '+ getDialPad("blind_tx") + '\
              </div>\
              <div class="col-xs-12 col-xs-offset-1">\
                  <div class="col-xs-2">\
                      <button type="button" class="btn col-xs-12 hold" disabled="true"><i class="fa fa-pause"></i></button>\
                  </div>\
                  <div class="col-xs-2">\
                      <button type="button" class="btn col-xs-12 mute"><i class="fa fa-microphone"></i></button>\
                  </div>\
                  <div class="col-xs-2">\
                      <button type="button" class="btn col-xs-12 dtmf"><i class="fa fa-th"></i></button>\
                  </div>\
                  <div class="col-xs-2">\
                      <button type="button" class="btn col-xs-12 blind_transfer" disabled="true" title="Blind Transfer"><i class="fa fa-mail-forward"></i></button>\
                  </div>\
                  <div class="col-xs-2">\
                      <button type="button" class="btn col-xs-12 btn-danger hangup"><i class="fa fa-phone" style="transform:rotate(135deg);"></i></button>\
                  </div>\
              </div>\
              <div class="col-xs-12">&nbsp;</div>\
              <div class="col-xs-12">\
              </div> \
            </div>\
        </div>\
        </div>';
}

let getDialPad = (_action) => {
    return '<div class="col-sm-12">\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="1">1</span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="2">2<span class="users-list-date">ABC</span></span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="3">3<span class="users-list-date">DEF</span></span>\
            </div>\
        </div>\
        <div class="col-sm-12">\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="4">4<span class="users-list-date">GHI</span></span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="5">5<span class="users-list-date">JKL</span></span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="6">6<span class="users-list-date">MNO</span></span>\
            </div>\
        </div>\
        <div class="col-sm-12">\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="7">7<span class="users-list-date">PQRS</span></span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="8">8<span class="users-list-date">TUV</span></span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="9">9<span class="users-list-date">WXYZ</span></span>\
            </div>\
        </div>\
        <div class="col-xs-12">\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="*">*</span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="0">0<span class="users-list-date">+</span></span>\
            </div>\
            <div class="col-xs-4 text-center">\
                <span class="btn btn-flat '+ _action + '_btn btn-sm" data-dialpad="#">#</span>\
            </div>\
        </div>';
}

let _openUpNumPad = (element, padState) => {
    // Check if number pad is already oepned or not
    const otherElementSelector = (padState == 'dtmf_pad') ? 'blind_tx_pad' : 'dtmf_pad';
    if ($(element).is(':visible')) {
        $(element).hide();
    } else {
        const _elemSelector = $(element).parent().find('.' + otherElementSelector);
        if (_elemSelector.length == 1) {
            _otherElement = _elemSelector[0];
            if ($(_otherElement).is(':visible')) {
                $(_otherElement).hide();
            }
        }
        $(element).show();
        $(element).find('.external_txt').focus(); // NOTE : Focus should be on text box after displaying numeric pad
    }
}

$('body').on('click', '.dtmf', function (e) {
    let _dtmfPadSelector = $(this).parent().parent().parent().find('.dtmf_pad');
    if (_dtmfPadSelector.length == 1) {
        _openUpNumPad(_dtmfPadSelector[0], 'dtmf_pad')
    }
});

$('body').on('click', '.blind_transfer', function (e) {
    let _dtmfPadSelector = $(this).parent().parent().parent().find('.blind_tx_pad');
    if (_dtmfPadSelector.length == 1) {
        _openUpNumPad(_dtmfPadSelector[0], 'blind_tx_pad')
    }
});

let dtmfBtnPressed = (element) => {
    let dtmfBtnVal = $(element).attr('data-dialpad'); // Get value of pressed dtmf button
    let _yourStr = $(element).closest('.dtmf_pad').find("input.external_txt").val();
    $(element).closest('.dtmf_pad').find("input.external_txt").val(_yourStr + dtmfBtnVal); // Append pressed dtmf value to text box
    $(element).closest('.dtmf_pad').find("input.external_txt").focus(); // Set focus to text box
    phone.sendDTMF(dtmfBtnVal);
}

let blidnTxBtnPressed = (element) => {
    let blindTxBtnVal = $(element).attr('data-dialpad'); // Get value of pressed dtmf button
    let _yourStr = $(element).closest('.blind_tx_pad').find("input.external_txt").val();
    $(element).closest('.blind_tx_pad').find("input.external_txt").val(_yourStr + blindTxBtnVal); // Append pressed dtmf value to text box
    $(element).closest('.blind_tx_pad').find("input.external_txt").focus(); // Set focus to text box
}

let blidnTx = (element) => {
    let _yourStr = $(element).closest('.blind_tx_pad').find("input.external_txt").val();
    phone.blindTx(_yourStr);
}

let _timerData;
let _enableTimer = () => {
    let previousTime = $('._sessionDiv').find('._timer').text();
    let previousTimeData = previousTime.split(":");
    let hours = Number(previousTimeData[0]);
    let minutes = Number(previousTimeData[1]);
    let seconds = Number(previousTimeData[2]);
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            hours++;
        }
    }
    const _callDuration = (hours > 9 ? hours : "0" + hours) + " : " + (minutes > 9 ? minutes : "0" + minutes) + " : " + (seconds > 9 ? seconds : "0" + seconds);
    $('._sessionDiv').find('._timer').text(_callDuration);
}

let clearTimer = () => {

    clearInterval(_timerData);
}

let enableTimer = () => {
    _timerData = setInterval(() => { _enableTimer() }, 1000);
}

let toggleHold = (element) => {
    const _holdState = $(element).attr('data-state');
    let _state = 'hold';
    if (isEmpty(_holdState) || _holdState == 'hold') {
        $(element).attr('data-state', 'unhold');
        $(element).html('<i class="fa fa-play"></i>');
    } else {
        _state = 'unhold';
        $(element).attr('data-state', 'hold');
        $(element).html('<i class="fa fa-pause"></i>');
    }
    phone.toggleHold(_state);
}

let toggleMute = (element) => {
    const _muteState = $(element).attr('data-state');
    let _state = 'mute';
    if (isEmpty(_muteState) || _muteState == 'mute') {
        $(element).attr('data-state', 'unmute');
        $(element).html('<i class="fa fa-microphone-slash"></i>');
    } else {
        _state = 'unmute';
        $(element).attr('data-state', 'mute');
        $(element).html('<i class="fa fa-microphone"></i>');
    }
    phone.toggleMute(_state);
}

let answerCall = (element) => {
    let _state = $(element).attr('data-state');
    $('._sessionDiv').remove();
    phone.answer(_state);
    console.log('We\'ll answer call.');
}

$('body').on('click', '.dtmf_btn', function (e) {
    dtmfBtnPressed($(this));
});

$('body').on('click', '.blind_tx_btn', function (e) {
    blidnTxBtnPressed($(this));
});

$('body').on('click', '.blind_tx', function (e) {
    blidnTx($(this));
});

$('body').on('click', '.hangup', function (e) {
    phone.hangup();
});

$('body').on('click', '.hold', function (e) {
    toggleHold($(this));
});

$('body').on('click', '.mute', function (e) {
    toggleMute($(this));
});

$('body').on('click', '.answer', function (e) {
    answerCall($(this));
});
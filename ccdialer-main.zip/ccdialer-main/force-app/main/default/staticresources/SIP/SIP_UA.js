 let UA;
    let _callSession = null;
    let _accountCreds;
    let soundPlayer = new Audio();
    //soundPlayer.volume = 10;

    window.phone = {
        createUA: () => {
            //_accountCreds = store.get('_accountCreds');
            _accountCreds = {
                CEPDOCUPAD__Sip_Extension__c: '100485501',
                CEPDOCUPAD__Sip_Server__c: 'sip3.cloud-connect.in',
                CEPDOCUPAD__Sip_Password__c: 'C@123456c',
                CEPDOCUPAD__Wss_Server__c: 'wss://sip3.cloud-connect.in:7443'

            }
            let sipJSSettings = {
                uri: 'sip:' + _accountCreds.CEPDOCUPAD__Sip_Extension__c + '@' + _accountCreds.CEPDOCUPAD__Sip_Server__c,
                password: _accountCreds.CEPDOCUPAD__Sip_Password__c,
                allowLegacyNotifications: true,
                transportOptions: {
                    wsServers: [_accountCreds.CEPDOCUPAD__Wss_Server__c],
                    traceSip: true,
                    maxReconnectionAttempts: 300
                },
                sessionDescriptionHandlerFactoryOptions: {
                    peerConnectionOptions: {
                        iceCheckingTimeout: 5000,
                        rtcConfiguration: {
                            iceTransportPolicy: 'all',
                            iceServers: [],
                            iceServers: [{
                                urls: 'stun:stun.l.google.com:19302'
                            }]
                        }
                    }
                },
                displayName: _accountCreds.CEPDOCUPAD__Sip_Extension__c,
                authorizationUser: null,
                register: true,
                rel100: SIP.C.supported.SUPPORTED,
                userAgentString: 'SIP Phone',
            }

            UA = new SIP.UA(sipJSSettings);
            UA.on('connecting', () => {
                updateRegisterState('connecting');
            });
            UA.on('connected', () => {
                updateRegisterState('disconnected');
            });
            UA.on('disconnected', () => {
                updateRegisterState('disconnected');
            });
            UA.on('registered', () => {
                updateRegisterState('registered');
            });
            UA.on('unregistered', () => {
                updateRegisterState('unregistered');
            });
            UA.on('registrationFailed', () => {
                updateRegisterState('unregistered');
            });
            UA.on('invite', (_session) => {
                session.newSession(_session);
            });
        },
        logout: () => {
            try {
                UA.unregister();
                UA.stop();
            } catch (e) {
                console.log('Exception occured.', e);
            }
        },
        dial: (number, video = false) => {
            try {
                if (UA.isRegistered()) {
                    if (!isEmpty(number)) {
                        if (_callSession != null) {
                            //console.error("Maximum Call Limit Reached");
                            return;
                        }
                        $('._dialpadBox').hide(() => {
                            $('._callControls').show();
                        });
                        const _constraints = { audio: true, video: video };
                        _callSession = UA.invite(number, {
                            sessionDescriptionHandlerOptions: {
                                constraints: _constraints,
                                RTCConstraints: { "optional": [{ 'DtlsSrtpKeyAgreement': 'true' }] },
                            },
                            extraHeaders: ["X-instance-id: a61ae308b95c507d"]
                        });
                        session.newSession(_callSession);
                    } else {
                        console.error("Number is required.", (video) ? 'Video Call' : 'Audio Call');
                    }
                } else {
                    console.error("SIP UA is not registered.");
                }
            } catch (e) {
                console.error("SIP UA is not enabled.");
            }
        },
        hangup: () => {
            session.hangup();
        },
        answer: (_state) => {
            session.answer(_state);
        },
        toggleHold: (_state) => {
            session.toggleHold(_state);
        },
        toggleMute: (_state) => {
            session.toggleMute(_state);
        },
        sendDTMF: (_dtmf) => {
            session.sendDTMF(_dtmf);
        },
        blindTx: (_blindTxTo) => {
            session.blindTx(_blindTxTo);
        }
    }

    window.session = {
        newSession: (_session) => {
            const callDirection = (_session.accept) ? 'incoming' : 'outgoing';
            const displayName = (_session && _session.remoteIdentity.displayName) || _session.remoteIdentity.uri.user;
            const _callerNumber = _session.remoteIdentity.uri.user;

            if (callDirection == 'incoming') {
                if (_callSession != null) {
                    _session.reject();
                    console.error("Maximum Call Limit Reached");
                    return;
                }
                $('._dialpadBox').hide(() => {
                    $('._callControls').show();
                });
                _callSession = _session;
            }
            handleCallSession({
                from: _callerNumber,
                fromName: displayName,
                callDirection: callDirection,
                sessionId: _session.id
            });

            if (callDirection == 'incoming') {
                console.info('You have an incoming call from ' + displayName, 'Incoming Call');
                soundPlayer.setAttribute("src", "assets/sounds/play_file.ogg");
                soundPlayer.setAttribute("loop", "true"); //For continuous ringing
                soundPlayer.play();
            }
            session.sessionHandler(_session);

        },

        attachStream: (_session) => {
            let pc = _session.sessionDescriptionHandler.peerConnection;
            let remoteView = document.getElementById('remoteVideo');

            let remoteStream = new MediaStream();
            pc.getReceivers().forEach(function (receiver) {
                remoteStream.addTrack(receiver.track);
            });

            if (typeof remoteView.srcObject !== 'undefined') {
                remoteView.srcObject = remoteStream;
            } else if (typeof remoteView.src !== 'undefined') {
                remoteView.src = window.URL.createObjectURL(remoteStream);
            } else {
                console.log('Error attaching stream to popup remoteVideo element.');
            }

            let localStream = new MediaStream();
            let localView = document.getElementById('localVideo');
            pc.getSenders().forEach(function (sender) {
                localStream.addTrack(sender.track);
            });
            if (typeof localView.srcObject !== 'undefined') {
                localView.srcObject = remoteStream;
            } else if (typeof localView.src !== 'undefined') {
                localView.src = window.URL.createObjectURL(localStream);
            } else {
                console.log('Error attaching stream to popup remoteVideo element.');
            }
        },

        sessionHandler: (_session) => {
            _session.on('progress', () => {
                $('._videoControls').show();
                soundPlayer.pause();
                console.info('Call is in progress');
            });
            _session.on('accepted', () => {
                soundPlayer.pause();
                $('._videoControls').show();
                console.info('Call has been accepted');
                $('.hold').attr('disabled', false);
                $('.blind_transfer').attr('disabled', false);
                enableTimer();
                let pc = _session.sessionDescriptionHandler.peerConnection;

                let remoteStream = new MediaStream();
                pc.getReceivers().forEach((receiver) => {
                    remoteStream.addTrack(receiver.track);
                });
                let remoteView = document.getElementById('remoteVideo');
                if (typeof remoteView.srcObject !== 'undefined') {
                    remoteView.srcObject = remoteStream;
                } else if (typeof remoteView.src !== 'undefined') {
                    remoteView.src = window.URL.createObjectURL(remoteStream);
                } else {
                    console.log('Error attaching stream to popup remoteVideo element.');
                }
                let localStream = new MediaStream();
                pc.getSenders().forEach((sender) => {
                    localStream.addTrack(sender.track);
                });
                let localView = document.getElementById('localVideo');
                if (typeof localView.srcObject !== 'undefined') {
                    localView.srcObject = localStream;
                } else if (typeof localView.src !== 'undefined') {
                    localView.src = window.URL.createObjectURL(localStream);
                } else {
                    console.log('Error attaching stream to popup remoteVideo element.');
                }
            });
            _session.on('trackAdded', () => {
                soundPlayer.pause();
                $('._videoControls').show();
                let pc = _session.sessionDescriptionHandler.peerConnection;
                let remoteStream = new MediaStream();
                pc.getReceivers()
                    .forEach((receiver) => {
                        remoteStream.addTrack(receiver.track);
                    });
                let remoteView = document.getElementById('remoteVideo');
                if (typeof remoteView.srcObject !== 'undefined') {
                    remoteView.srcObject = remoteStream;
                } else if (typeof remoteView.src !== 'undefined') {
                    remoteView.src = window.URL.createObjectURL(remoteStream);
                } else {
                    console.log('Error attaching stream to popup remoteVideo element.');
                }
            });
            _session.on('bye', () => {
                soundPlayer.pause();
                clearTimer();
                $('._callControls').hide(() => {
                    $('._dialpadBox').show();
                });
                console.info('Call has been ended.');
                $('._sessionDiv').remove();
                _callSession = null;
            });
            _session.on('failed', (request, cause) => {
                soundPlayer.pause();
                clearTimer();
                $('._callControls').hide(() => {
                    $('._dialpadBox').show();
                });
                if (cause != "undefined" && cause != undefined) {
                    console.info('Call has been failed due to cause ' + cause);
                }
                $('._sessionDiv').remove();
                _callSession = null;
            });
            _session.on('terminated', (request, cause) => {
                clearTimer();
                $('._callControls').hide(() => {
                    $('._dialpadBox').show();
                });
                soundPlayer.pause();
                if (cause != "undefined" && cause != undefined) {
                    console.info('Call has been terminated due to cause ' + cause);
                }
                $('._sessionDiv').remove();
                _callSession = null;
            });
        },
        hangup: () => {
            if (!_callSession) {
                return;
            } else if (_callSession.startTime) { // Connected
                _callSession.bye();
            } else if (_callSession.reject) { // Incoming
                _callSession.reject();
            } else if (_callSession.cancel) { // Outbound
                _callSession.cancel();
            }
        },
        answer: (_state) => {

            if (!_callSession) {
                return;
            } else if (_callSession.accept && !_callSession.startTime) {
                const _videoCall = (_state == 'video') ? true : false;
                let options = {
                    sessionDescriptionHandlerOptions: {
                        constraints: { audio: true, video: _videoCall }
                    }
                };
                try {
                    const callDirection = (_callSession.accept) ? 'incoming' : 'outgoing';
                    const displayName = (_callSession && _callSession.remoteIdentity.displayName) || _callSession.remoteIdentity.uri.user;
                    const _callerNumber = _callSession.remoteIdentity.uri.user;
                    $('._activeCalls').append(generateOutgoingCallUI({
                        from: _callerNumber,
                        fromName: displayName,
                        callDirection: callDirection,
                        sessionId: _callSession.id
                    }));
                    _callSession.accept(options);

                    //      	handleCallSession({
                    // 	from : _callerNumber,
                    // 	fromName : displayName,
                    // 	callDirection : callDirection,
                    // 	sessionId : _callSession.id
                    // });

                } catch (e) {
                    console.log(e);
                }
            }
        },
        toggleHold: (_state) => {
            if (!_callSession) {
                return;
            } else {
                if (_state == 'hold') {
                    _callSession.hold();
                } else {
                    _callSession.unhold();
                }
            }
        },
        toggleMute: (_state) => {
            if (!_callSession) {
                return;
            } else {
                (_state == 'mute') ? _callSession.mute() : _callSession.unmute();
            }
        },
        sendDTMF: (_dtmf) => {
            if (!_callSession) {
                return;
            } else {
                _callSession.dtmf(_dtmf);
            }
        },
        blindTx: (_blindTxTo) => {
            if (!_callSession) {
                return;
            } else {
                _callSession.refer(_blindTxTo, { extraHeaders: ['Referred-By : sip:' + _accountCreds.CEPDOCUPAD__Sip_Extension__c] });
            }
        }
    }
let isEmpty = (string) => {
	if (string == null || string == "" || string == undefined ){
		return true;
	} else {
		return false;
  	}
}
let getVal = (selector) => {
	return $(selector).val().trim();
}
let setVal = (selector, value ) => {
	$(selector).val(value);
}
let validate = (value, method = "required") => {
	switch (method) {
		case 'required' :
			return isEmpty(value);
			break;
		case 'alphanumeric' :
			const allowedLetters = /^[0-9a-zA-Z]+$/;
			return !value.match(allowedLetters);	
			break;
		default :
			break;
	}
}